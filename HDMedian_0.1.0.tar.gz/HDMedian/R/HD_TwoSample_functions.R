require(mvtnorm)
require(ICSNP)
require(Gmedian)
require(extraDistr)
require(flare)

#' Two-sample test for high-dimensional medians based on geometric medians.
#'
#' @description Let \eqn{m_1} and \eqn{m_2} be the population medians of the two
#' groups. The hypothesis testing problem is
#' \deqn{H_0: m_1=m_2 ~~\text{versus}~~ H_1: m_1\neq m_2.}
#' The p-value of the test is approximated by the multiplier bootstrap.
#' The results include both approaches with and without standardization.
#' There are two different bootstrap approaches for the standardized statistic,
#' one standardization is based on the original data (std_ver1), the other
#' standardization method is based on the bootstrap sample (std_ver2).
#'
#' @param X1 a \eqn{n_1\times p} matrix containing data from the first group
#' @param X2 a \eqn{n_2\times p} matrix containing data from the second group
#' @param n1 the sample size of the first group
#' @param n2 the sample size of the second group
#' @param p dimensions of the data
#' @param weight specify the type of weight variable in the multiplier
#' bootstrap, a common choice is \code{Rademacher}
#' @param n_boot number of bootstrap iterations
#' @param alpha significance level of the test
#' @details The results include both approaches with and without standardization.
#' The approach with standardization refers to the case of \eqn{\tau=0} in
#' Cheng, Lin and Peng (2023), while the approach without standardization
#' refers to the case of \eqn{\tau=1} in the paper.
#' There are two different bootstrap approaches for the standardized statistic,
#' one standardization is based on the original data (std_ver1), the other
#' standardization method is based on the bootstrap sample (std_ver2).
#'
#' @return A list containing the following objects:
#' \itemize{
#'   \item alpha - the pre-specified significance level
#'   \item res_test_non_std - result of the test without standardization
#'   \item res_test_std_ver1 - result of the test with standardization
#'   based on the original data
#'   \item res_test_std_ver2 - result of the test with standardization
#'   based on the the bootstrap sample
#'   \item p_val_non_std - p-value of the test without standardization
#'   \item p_val_std_ver1 - p-value of the test with standardization
#'   based on the original data
#'   \item p_val_std_ver2 - p-value of the test with standardization
#'   based on the the bootstrap sample
#'   \item test_stat_medn_non_std - value of the test statistic without
#'   standardization
#'   \item test_stat_medn_std - value of the test statistic with standardization
#'   \item res_medn_boot_non_std - a vector of length \code{n_boot} containing
#'   values of the bootstrap version of the test statistic without standardization
#'   \item res_medn_boot_std_ver1 - a vector of length \code{n_boot} containing
#'   values of the bootstrap version of the test statistic with standardization
#'   based on the original data
#'   \item res_medn_boot_std_ver2 - a vector of length \code{n_boot} containing
#'   values of the bootstrap version of the test statistic with standardization
#'   based on the the bootstrap sample
#' }
#'
#' @examples
#' X1 <- matrix(rnorm(5000, 0, 1), 50, 100)
#' X2 <- matrix(rnorm(5000, 0.2, 1), 50, 100)
#' Test_TwoSample_HD_Median(X1, X2, 50, 50, 100)
#'
Test_TwoSample_HD_Median <- function (X1, X2, n1, n2, p, weight="Rademacher",
                                      n_boot=1000, alpha=0.05) {

  medn_X1 <- drop(Weiszfeld(X1)$median)
  medn_X2 <- drop(Weiszfeld(X2)$median)

  ## calculate the difference of the sample medians
  medn_diff <- medn_X1 - medn_X2

  ## calculate the test statistic without standardization
  test_stat_medn <- sqrt(n1)*max(abs(medn_diff))

  ## calculate the test statistic with standardization
  X1_central <- X1-rep(1, n1)%o%medn_X1
  norm_X1 <- sqrt(diag(X1_central%*%t(X1_central)))
  B_X1 <- (t(X1_central)%*%diag(1/norm_X1))%*%t(t(X1_central)%*%diag(1/norm_X1))/n1

  X2_central <- X2-rep(1, n2)%o%medn_X2
  norm_X2 <- sqrt(diag(X2_central%*%t(X2_central)))
  B_X2 <- (t(X2_central)%*%diag(1/norm_X2))%*%t(t(X2_central)%*%diag(1/norm_X2))/n2

  c_X1 <- mean(1/norm_X1); c_X2 <- mean(1/norm_X2)
  std_X12 <- sqrt(diag(B_X1/c_X1^2+n1*B_X2/(n2*c_X2^2)))

  test_stat_medn_std <- sqrt(n1)*max(abs(medn_diff/std_X12))

  ## bootstrap
  res_medn_boot <- rep(0, n_boot)
  res_medn_std_boot <- rep(0, n_boot)
  res_medn_std_boot_ver1 <- rep(0, n_boot)

  for(bb in 1:n_boot){
    if (weight == "Rademacher") {
      Z_X1 <- rsign(n1)%o%rep(1, p)
      Z_X2 <- rsign(n2)%o%rep(1, p)
    } else if (weight == "normal") {
      Z_X1 <- rnorm(n1)%o%rep(1,p)
      Z_X2 <- rnorm(n2)%o%rep(1,p)
    }

    Y1 <- X1_central*Z_X1
    Y2 <- X2_central*Z_X2

    ## calculate the bootstrap version of the medians
    medn_Y1 <- drop(Weiszfeld(Y1)$median)
    medn_Y2 <- drop(Weiszfeld(Y2)$median)

    medn_diff_boot <- medn_Y1 - medn_Y2

    ## calculate bootstrap version of the test statisitc without standardization
    res_medn_boot[bb] <- sqrt(n1)*max(abs(medn_diff_boot))

    ## calculate bootstrap version of the test statistic with standardization
    Y1_central <- Y1-rep(1, n1)%o%medn_Y1
    norm_Y1 <- sqrt(diag(Y1_central%*%t(Y1_central)))
    B_Y1 <- (t(Y1_central)%*%diag(1/norm_Y1))%*%t(t(Y1_central)%*%diag(1/norm_Y1))/n1

    Y2_central <- Y2-rep(1, n2)%o%medn_Y2
    norm_Y2 <- sqrt(diag(Y2_central%*%t(Y2_central)))
    B_Y2 <- (t(Y2_central)%*%diag(1/norm_Y2))%*%t(t(Y2_central)%*%diag(1/norm_Y2))/n2

    c_Y1 <- mean(1/norm_Y1); c_Y2 <- mean(1/norm_Y2)
    std_Y12 <- sqrt(diag(B_Y1/c_Y1^2+n1*B_Y2/(n2*c_Y2^2)))

    res_medn_std_boot[bb] <- sqrt(n1)*max(abs(medn_diff_boot/std_Y12))


    res_medn_std_boot_ver1[bb] <- sqrt(n1)*max(abs(medn_diff_boot/std_X12))
  }

  res_test_non_std <- (test_stat_medn > quantile(res_medn_boot, 1-alpha))
  res_test_std <- (test_stat_medn_std > quantile(res_medn_std_boot, 1-alpha))
  res_test_std_ver1 <- (test_stat_medn_std > quantile(res_medn_std_boot_ver1, 1-alpha))

  p_val_non_std <- mean(test_stat_medn < res_medn_boot)
  p_val_std <- mean(test_stat_medn_std < res_medn_std_boot)
  p_val_std_ver1 <- mean(test_stat_medn_std < res_medn_std_boot_ver1)

  return(list("alpha"=alpha,
              "res_test_non_std"=c("not_reject", "reject")[res_test_non_std+1],
              "res_test_std_ver1"=c("not_reject", "reject")[res_test_std_ver1+1],
              "res_test_std_ver2"=c("not_reject", "reject")[res_test_std+1],
              "p_val_non_std"=p_val_non_std,
              "p_val_std_ver1"=p_val_std_ver1,
              "p_val_std_ver2"=p_val_std,
              "test_stat_medn_non_std"=test_stat_medn,
              "test_stat_medn_std"=test_stat_medn_std,
              "res_medn_boot_non_std"=res_medn_boot,
              "res_medn_boot_std_ver1"=res_medn_std_boot_ver1,
              "res_medn_boot_std_ver2"=res_medn_std_boot))
}


#' Simultaneous confidence intervals for the difference between two-sample
#' high-dimensional medians based on geometric medians
#'
#' @description Let \eqn{m_1} and \eqn{m_2} be the population medians of the two
#' groups. The simultaneous confidence intervals is valid for all components of
#' \eqn{m_1-m_2}. The limits of the intervals are approximated by multiplier
#' bootstrap. The results include both approaches with and without standardization.
#' There are two different bootstrap approaches for the standardized statistic,
#' one standardization is based on the original data (std_ver1), the other
#' standardization method is based on the bootstrap sample (std_ver2).
#'
#' @param X1 a \eqn{n_1\times p} matrix containing data from the first group
#' @param X2 a \eqn{n_2\times p} matrix containing data from the second group
#' @param n1 the sample size of the first group
#' @param n2 the sample size of the second group
#' @param p dimensions of the data
#' @param weight specify the type of weight variable in the multiplier
#' bootstrap, a common choice is \code{Rademacher}
#' @param n_boot number of bootstrap iterations
#' @param level confidence level of the confidence intervals
#'
#' @details The results include both approaches with and without standardization.
#' The approach with standardization refers to the case of \eqn{\tau=0} in
#' Cheng, Lin and Peng (2023), while the approach without standardization
#' refers to the case of \eqn{\tau=1} in the paper.
#' There are two different bootstrap approaches for the standardized statistic,
#' one standardization is based on the original data (std_ver1), the other
#' standardization method is based on the bootstrap sample (std_ver2).
#'
#' @return A list containing the following objects:
#' \itemize{
#'   \item level - the pre-specified confidence level
#'   \item res_SCI_non_std - a \eqn{2\times p} matrix containing the
#'   simultaneous confidence intervals based on non-standardized medians,
#'   the first row contains the lower bounds
#'   and the second contains the upper bounds
#'   \item res_SCI_std_ver1 - a \eqn{2\times p} matrix containing the
#'   simultaneous confidence intervals based on standardized medians,
#'   the first row contains the lower bounds
#'   and the second contains the upper bounds.
#'   The standardization is based on the original data.
#'   \item res_SCI_std_ver2 - a \eqn{2\times p} matrix containing the
#'   simultaneous confidence intervals based on standardized medians,
#'   the first row contains the lower bounds
#'   and the second contains the upper bounds
#'   The standardization is based on the bootstrap sample.
#' }
#'
#' @examples
#' X1 <- matrix(rnorm(5000, 0, 1), 50, 100)
#' X2 <- matrix(rnorm(5000, 0.2, 1), 50, 100)
#' SCI_TwoSample_HD_Median(X1, X2, 50, 50, 100)
#'
SCI_TwoSample_HD_Median <- function (X1, X2, n1, n2, p, weight="Rademacher",
                                     n_boot=1000, level=0.95) {

  medn_X1 <- drop(Weiszfeld(X1)$median)
  medn_X2 <- drop(Weiszfeld(X2)$median)

  ## calculate the difference of the sample medians
  medn_diff <- medn_X1 - medn_X2

  ## calculate the test statistic with standardization
  X1_central <- X1-rep(1, n1)%o%medn_X1
  norm_X1 <- sqrt(diag(X1_central%*%t(X1_central)))
  B_X1 <- (t(X1_central)%*%diag(1/norm_X1))%*%t(t(X1_central)%*%diag(1/norm_X1))/n1

  X2_central <- X2-rep(1, n2)%o%medn_X2
  norm_X2 <- sqrt(diag(X2_central%*%t(X2_central)))
  B_X2 <- (t(X2_central)%*%diag(1/norm_X2))%*%t(t(X2_central)%*%diag(1/norm_X2))/n2

  c_X1 <- mean(1/norm_X1); c_X2 <- mean(1/norm_X2)
  std_X12 <- sqrt(diag(B_X1/c_X1^2+n1*B_X2/(n2*c_X2^2)))

  ## bootstrap
  res_medn_boot <- rep(0, n_boot)
  res_medn_std_boot <- rep(0, n_boot)
  res_medn_std_boot_ver1 <- rep(0, n_boot)

  for(bb in 1:n_boot){
    if (weight == "Rademacher") {
      Z_X1 <- rsign(n1)%o%rep(1, p)
      Z_X2 <- rsign(n2)%o%rep(1, p)
    } else if (weight == "normal") {
      Z_X1 <- rnorm(n1)%o%rep(1,p)
      Z_X2 <- rnorm(n2)%o%rep(1,p)
    }

    Y1 <- X1_central*Z_X1
    Y2 <- X2_central*Z_X2

    ## calculate the bootstrap version of the medians
    medn_Y1 <- drop(Weiszfeld(Y1)$median)
    medn_Y2 <- drop(Weiszfeld(Y2)$median)

    medn_diff_boot <- medn_Y1 - medn_Y2

    ## calculate bootstrap version of the test statisitc without standardization
    res_medn_boot[bb] <- sqrt(n1)*max(abs(medn_diff_boot))

    ## calculate bootstrap version of the test statistic with standardization
    Y1_central <- Y1-rep(1, n1)%o%medn_Y1
    norm_Y1 <- sqrt(diag(Y1_central%*%t(Y1_central)))
    B_Y1 <- (t(Y1_central)%*%diag(1/norm_Y1))%*%t(t(Y1_central)%*%diag(1/norm_Y1))/n1

    Y2_central <- Y2-rep(1, n2)%o%medn_Y2
    norm_Y2 <- sqrt(diag(Y2_central%*%t(Y2_central)))
    B_Y2 <- (t(Y2_central)%*%diag(1/norm_Y2))%*%t(t(Y2_central)%*%diag(1/norm_Y2))/n2

    c_Y1 <- mean(1/norm_Y1); c_Y2 <- mean(1/norm_Y2)
    std_Y12 <- sqrt(diag(B_Y1/c_Y1^2+n1*B_Y2/(n2*c_Y2^2)))

    res_medn_std_boot[bb] <- sqrt(n1)*max(abs(medn_diff_boot/std_Y12))

    res_medn_std_boot_ver1[bb] <- sqrt(n1)*max(abs(medn_diff_boot/std_X12))
  }

  res_SCI <- matrix(0, 2, p)
  res_SCI[1, ] <- medn_diff - quantile(res_medn_boot, level)/sqrt(n1)
  res_SCI[2, ] <- medn_diff + quantile(res_medn_boot, level)/sqrt(n1)

  res_SCI_std <- matrix(0, 2, p)
  tmp_quan <- quantile(res_medn_std_boot, level)
  res_SCI_std[1, ] <- medn_diff - std_X12*tmp_quan/sqrt(n1)
  res_SCI_std[2, ] <- medn_diff + std_X12*tmp_quan/sqrt(n1)

  res_SCI_std_ver1 <- matrix(0, 2, p)
  tmp_quan_ver1 <- quantile(res_medn_std_boot_ver1, level)
  res_SCI_std_ver1[1, ] <- medn_diff - std_X12*tmp_quan_ver1/sqrt(n1)
  res_SCI_std_ver1[2, ] <- medn_diff + std_X12*tmp_quan_ver1/sqrt(n1)

  return(list("level"=level,
              "res_SCI_non_std"=res_SCI,
              "res_SCI_std_ver1"=res_SCI_std_ver1,
              "res_SCI_std_ver2"=res_SCI_std))
}


#' Xue and Yao (2020)'s two-sample test for high-dimensional means
#'
#' @description Let \eqn{\mu_1} and \eqn{\mu_2} be the population means of the
#' two groups. The hypothesis testing problem is
#' \deqn{H_0: \mu_1=\mu_2 ~~\text{versus}~~ H_1: \mu_1\neq \mu_2.}
#' The p-value of the test is approximated by the multiplier bootstrap.
#'
#' @param X1 a \eqn{n_1\times p} matrix containing data from the first group
#' @param X2 a \eqn{n_2\times p} matrix containing data from the second group
#' @param n1 the sample size of the first group
#' @param n2 the sample size of the second group
#' @param p dimensions of the data
#' @param n_boot number of bootstrap iterations
#' @param alpha significance level of the test
#' @details As in Xue and Yao (2020), the test statistic is not standardized,
#' and the p-value of the test is approximated by the multiplier bootstrap with
#' normal weights.
#'
#' @return A list containing the following objects:
#' \itemize{
#'   \item alpha - the pre-specified significance level
#'   \item res_test_mean_non_std - result of the test without standardization
#'   \item p_val_mean_non_std - p-value of the test without standardization
#'   \item test_stat_mean_non_std - value of the test statistic without
#'   standardization
#'   \item res_mean_non_std_boot - a vector of length \code{n_boot} containing
#'   values of the bootstrap version of the test statistic without standardization
#' }
#'
#' @examples
#' X1 <- matrix(rnorm(5000, 0, 1), 50, 100)
#' X2 <- matrix(rnorm(5000, 0.2, 1), 50, 100)
#' Test_TwoSample_HD_Mean_XueYao(X1, X2, 50, 50, 100)
#'
Test_TwoSample_HD_Mean_XueYao <- function (X1, X2, n1, n2, p,
                                           n_boot=1000, alpha=0.05) {

  mean_X1 <- apply(X1, 2, mean)
  mean_X2 <- apply(X2, 2, mean)

  ## calculate the difference of the sample means
  mean_diff <- mean_X1 - mean_X2

  ## calculate the test statistic without standardization
  test_stat_mean <- sqrt(n1)*max(abs(mean_diff))

  X1_central <- X1-rep(1, n1)%o%mean_X1
  X2_central <- X2-rep(1, n2)%o%mean_X2

  ## bootstrap
  res_mean_boot <- rep(0, n_boot)

  for(bb in 1:n_boot){
    Z_X1 <- rnorm(n1)%o%rep(1,p)
    Z_X2 <- rnorm(n2)%o%rep(1,p)

    Y1 <- X1_central*Z_X1
    Y2 <- X2_central*Z_X2

    ## calculate the bootstrap version of the means
    mean_Y1 <- apply(Y1, 2, mean)
    mean_Y2 <- apply(Y2, 2, mean)

    mean_diff_boot <- mean_Y1 - mean_Y2

    res_mean_boot[bb] <- sqrt(n1)*max(abs(mean_diff_boot))
  }

  res_test <- (test_stat_mean > quantile(res_mean_boot, 1-alpha))
  p_val <- mean(test_stat_mean < res_mean_boot)

  return(list("alpha"=alpha,
              "res_test_mean_non_std"=c("not_reject", "reject")[res_test+1],
              "p_val_mean_non_std"=p_val,
              "test_stat_mean_non_std"=test_stat_mean,
              "res_mean_boot_non_std"=res_mean_boot))
}


#' Xue and Yao (2020)'s approach for constructing simultaneous confidence
#' intervals for the difference between two-sample high-dimensional means
#'
#' @description Let \eqn{\mu_1} and \eqn{\mu_2} be the population medians of the
#' two groups. The simultaneous confidence intervals is valid for all components
#' of \eqn{\mu_1-\mu_2}.
#'
#' @param X1 a \eqn{n_1\times p} matrix containing data from the first group
#' @param X2 a \eqn{n_2\times p} matrix containing data from the second group
#' @param n1 the sample size of the first group
#' @param n2 the sample size of the second group
#' @param p dimensions of the data
#' @param n_boot number of bootstrap iterations
#' @param level confidence level of the confidence intervals
#'
#' @details As in Xue and Yao (2020), the confidence intervals are built upon
#' non-standardized mean difference. The limits of the intervals are
#' approximated by multiplier bootstrap with normal weights.
#'
#' @return A list containing the following objects:
#' \itemize{
#'   \item level - the pre-specified confidence level
#'   \item res_SCI_mean_non_std - a \eqn{2\times p} matrix containing the
#'   simultaneous confidence intervals based on non-standardized means,
#'   the first row contains the lower bounds
#'   and the second contains the upper bounds
#' }
#'
#' @examples
#' X1 <- matrix(rnorm(5000, 0, 1), 50, 100)
#' X2 <- matrix(rnorm(5000, 0.2, 1), 50, 100)
#' SCI_TwoSample_HD_Mean_XueYao(X1, X2, 50, 50, 100)
#'
SCI_TwoSample_HD_Mean_XueYao <- function (X1, X2, n1, n2, p,
                                          n_boot=1000, level=0.95) {

  mean_X1 <- apply(X1, 2, mean)
  mean_X2 <- apply(X2, 2, mean)

  ## calculate the difference of the sample means
  mean_diff <- mean_X1 - mean_X2

  X1_central <- X1-rep(1, n1)%o%mean_X1
  X2_central <- X2-rep(1, n2)%o%mean_X2

  ## bootstrap
  res_mean_boot <- rep(0, n_boot)

  for(bb in 1:n_boot){
    Z_X1 <- rnorm(n1)%o%rep(1,p)
    Z_X2 <- rnorm(n2)%o%rep(1,p)

    Y1 <- X1_central*Z_X1
    Y2 <- X2_central*Z_X2

    ## calculate the bootstrap version of the means
    mean_Y1 <- apply(Y1, 2, mean)
    mean_Y2 <- apply(Y2, 2, mean)

    res_mean_boot[bb] <- sqrt(n1)*max(abs(mean_Y1 - mean_Y2))
  }

  res_SCI <- matrix(0, 2, p)
  res_SCI[1, ] <- mean_diff - quantile(res_mean_boot, level)/sqrt(n1)
  res_SCI[2, ] <- mean_diff + quantile(res_mean_boot, level)/sqrt(n1)

  return(list("level"=level,
              "res_SCI_mean_non_std"=res_SCI))
}


#' Konietschke et al.(2021)'s two-sample test for high-dimensional means
#'
#' @description Let \eqn{\mu_1} and \eqn{\mu_2} be the population means of the
#' two groups. The hypothesis testing problem is
#' \deqn{H_0: \mu_1=\mu_2 ~~\text{versus}~~ H_1: \mu_1\neq \mu_2.}
#' The p-value of the test is approximated by the multiplier bootstrap.
#'
#' @param X1 a \eqn{n_1\times p} matrix containing data from the first group
#' @param X2 a \eqn{n_2\times p} matrix containing data from the second group
#' @param n1 the sample size of the first group
#' @param n2 the sample size of the second group
#' @param p dimensions of the data
#' @param n_boot number of bootstrap iterations
#' @param alpha significance level of the test
#' @details As in Konietschke et al. (2021), the test statistic is standardized,
#' and the p-value of the test is approximated by the multiplier bootstrap with
#' Rademacher weights.
#'
#' @return A list containing the following objects:
#' \itemize{
#'   \item alpha - the pre-specified significance level
#'   \item res_test_mean_std - result of the test
#'   \item p_val_mean_std - p-value of the test
#'   \item test_stat_mean_std - value of the test statistic
#'   \item res_mean_std_boot - a vector of length \code{n_boot} containing
#'   values of the bootstrap version of the test statistic
#' }
#'
#' @examples
#' X1 <- matrix(rnorm(5000, 0, 1), 50, 100)
#' X2 <- matrix(rnorm(5000, 0.2, 1), 50, 100)
#' Test_TwoSample_HD_Mean_Konietschke(X1, X2, 50, 50, 100)
#'
Test_TwoSample_HD_Mean_Konietschke <- function (X1, X2, n1, n2, p,
                                                n_boot=1000, alpha=0.05) {

  mean_X1 <- apply(X1, 2, mean)
  mean_X2 <- apply(X2, 2, mean)

  ## calculate the difference of the sample means
  mean_diff <- mean_X1 - mean_X2

  ## calculate the test statistic with standardization
  S_X1 <- cov(X1)*(n1-1)/n1; S_X2 <- cov(X2)*(n2-1)/n2
  std_X12 <- sqrt(diag(S_X1 + n1*S_X2/n2))

  test_stat_mean_std <- sqrt(n1)*max(abs(mean_diff/std_X12))

  X1_central <- X1-rep(1, n1)%o%mean_X1
  X2_central <- X2-rep(1, n2)%o%mean_X2

  ## bootstrap
  res_mean_std_boot <- rep(0, n_boot)

  for(bb in 1:n_boot){
    Z_X1 <- rsign(n1)%o%rep(1, p)
    Z_X2 <- rsign(n2)%o%rep(1, p)

    Y1 <- X1_central*Z_X1
    Y2 <- X2_central*Z_X2

    ## calculate the bootstrap version of the means
    mean_Y1 <- apply(Y1, 2, mean)
    mean_Y2 <- apply(Y2, 2, mean)

    mean_diff_boot <- mean_Y1 - mean_Y2

    ## calculate bootstrap version of the test statistic with standardization
    ## Konietschke et al. (2021)
    S_Y1 <- cov(Y1)*(n1-1)/n1; S_Y2 <- cov(Y2)*(n2-1)/n2
    std_Y12 <- sqrt(diag(S_Y1 + n1*S_Y2/n2))

    res_mean_std_boot[bb] <- sqrt(n1)*max(abs(mean_diff_boot/std_Y12))
  }

  res_test_std <- (test_stat_mean_std > quantile(res_mean_std_boot, 1-alpha))
  p_val_std <- mean(test_stat_mean_std < res_mean_std_boot)

  return(list("alpha"=alpha,
              "res_test_mean_std"=c("not_reject", "reject")[res_test_std+1],
              "p_val_mean_std"=p_val_std,
              "test_stat_mean_std"=test_stat_mean_std,
              "res_mean_std_boot"=res_mean_std_boot))
}


#' Konietschke et al.(2021)'s approach for constructing simultaneous confidence
#' intervals for the difference between two-sample high-dimensional means
#'
#' @description Let \eqn{\mu_1} and \eqn{\mu_2} be the population medians of the
#' two groups. The simultaneous confidence intervals is valid for all components
#' of \eqn{\mu_1-\mu_2}.
#'
#' @param X1 a \eqn{n_1\times p} matrix containing data from the first group
#' @param X2 a \eqn{n_2\times p} matrix containing data from the second group
#' @param n1 the sample size of the first group
#' @param n2 the sample size of the second group
#' @param p dimensions of the data
#' @param n_boot number of bootstrap iterations
#' @param level confidence level of the confidence intervals
#'
#' @details As in Konietschke et al. (2021), the confidence intervals are built
#' upon standardized mean difference. The limits of the intervals are
#' approximated by multiplier bootstrap with Rademacher weights.
#'
#' @return A list containing the following objects:
#' \itemize{
#'   \item level - the pre-specified confidence level
#'   \item res_SCI_mean_std - a \eqn{2\times p} matrix containing the
#'   simultaneous confidence intervals based on standardized means,
#'   the first row contains the lower bounds
#'   and the second contains the upper bounds
#' }
#'
#' @examples
#' X1 <- matrix(rnorm(5000, 0, 1), 50, 100)
#' X2 <- matrix(rnorm(5000, 0.2, 1), 50, 100)
#' SCI_TwoSample_HD_Mean_Konietschke(X1, X2, 50, 50, 100)
#'
SCI_TwoSample_HD_Mean_Konietschke <- function (X1, X2, n1, n2, p,
                                               n_boot=1000, level=0.95) {

  mean_X1 <- apply(X1, 2, mean)
  mean_X2 <- apply(X2, 2, mean)

  ## calculate the difference of the sample means
  mean_diff <- mean_X1 - mean_X2

  S_X1 <- cov(X1)*(n1-1)/n1; S_X2 <- cov(X2)*(n2-1)/n2
  std_X12 <- sqrt(diag(S_X1 + n1*S_X2/n2))

  X1_central <- X1-rep(1, n1)%o%mean_X1
  X2_central <- X2-rep(1, n2)%o%mean_X2

  ## bootstrap
  res_mean_std_boot <- rep(0, n_boot)

  for(bb in 1:n_boot){
    Z_X1 <- rsign(n1)%o%rep(1, p)
    Z_X2 <- rsign(n2)%o%rep(1, p)

    Y1 <- X1_central*Z_X1
    Y2 <- X2_central*Z_X2

    ## calculate the bootstrap version of the means
    mean_Y1 <- apply(Y1, 2, mean)
    mean_Y2 <- apply(Y2, 2, mean)

    mean_diff_boot <- mean_Y1 - mean_Y2

    ## calculate bootstrap version of the test statistic with standardization
    ## Konietschke et al. (2021)
    S_Y1 <- cov(Y1)*(n1-1)/n1; S_Y2 <- cov(Y2)*(n2-1)/n2
    std_Y12 <- sqrt(diag(S_Y1 + n1*S_Y2/n2))

    res_mean_std_boot[bb] <- sqrt(n1)*max(abs(mean_diff_boot/std_Y12))
  }

  res_SCI_std <- matrix(0, 2, p)
  tmp_quan <- quantile(res_mean_std_boot, level)
  res_SCI_std[1, ] <- mean_diff - std_X12*tmp_quan/sqrt(n1)
  res_SCI_std[2, ] <- mean_diff + std_X12*tmp_quan/sqrt(n1)

  return(list("level"=level,
              "res_SCI_mean_std"=res_SCI_std))
}


#' MANOVA test for high-dimensional medians based on geometric medians.
#'
#' @description Let \eqn{m_1},..., \eqn{m_K} be the population medians of \eqn{K}
#' groups. The hypothesis testing problem is
#' \deqn{H_0: m_1=\cdots=m_K ~~\text{versus}~~ H_1: H_0~\text{is not true}.}
#' The p-value of the test is approximated by the multiplier bootstrap.
#' The results include both approaches with and without standardization.
#' There are two different bootstrap approaches for the standardized statistic,
#' one standardization is based on the original data (std_ver1), the other
#' standardization method is based on the bootstrap sample (std_ver2).
#'
#' @param dat a list of data matrices, with each element from each group
#' @param K the number of groups
#' @param N a vector contains the number of observation in each group
#' @param p dimensions of the data
#' @param n_boot the number of bootstrap iterations
#' @details The results include both approaches with and without standardization.
#' The approach with standardization refers to the case of \eqn{\tau=0} in
#' Cheng, Lin and Peng (2023), while the approach without standardization
#' refers to the case of \eqn{\tau=1} in the paper.
#' There are two different bootstrap approaches for the standardized statistic,
#' one standardization is based on the original data (std_ver1), the other
#' standardization method is based on the bootstrap sample (std_ver2).
#'
#' @return A list containing the following objects:
#' \itemize{
#'   \item test_p_value_non_std - p-value of the test without standardization
#'   \item test_p_value_std_ver1 - p-value of the test with standardization
#'   based on the original data
#'   \item test_p_value_std_ver2 - p-value of the test with standardization
#'   based on the the bootstrap sample
#'   \item test_stat_median_non_std - value of the test statistic without
#'   standardization
#'   \item test_stat_median_std - value of the test statistic with standardization
#'   \item res_median_boot_non_std - a vector of length \code{n_boot} containing
#'   values of the bootstrap version of the test statistic without standardization
#'   \item res_median_boot_std_ver1 - a vector of length \code{n_boot} containing
#'   values of the bootstrap version of the test statistic with standardization
#'   based on the original data
#'   \item res_median_boot_std_ver2 - a vector of length \code{n_boot} containing
#'   values of the bootstrap version of the test statistic with standardization
#'   based on the the bootstrap sample
#' }
#'
#' @examples
#' X1 <- matrix(rnorm(5000, 0, 1), 50, 100)
#' X2 <- matrix(rnorm(5000, 0.2, 1), 50, 100)
#' X3 <- matrix(rnorm(5000, 0.4, 1), 50, 100)
#' dat <- list(X1, X2, X3)
#' N <- c(50, 50, 50)
#' MANOVA_Median(dat, K=3, N, p=100, n_boot=400)
#'
MANOVA_Median <- function (dat, K, N, p, n_boot=400) {
  median_list <- vector("list", K)
  for (k in 1:K) {
    median_list[[k]] <- drop(Weiszfeld(dat[[k]])$median)
  }

  dif_matrix <- matrix(0, K, K)
  for (k1 in 1:(K-1)) {
    for (k2 in (k1+1):K) {
      tmp1 <- abs(median_list[[k1]]-median_list[[k2]])
      dif_matrix[k1, k2] <- max(sqrt(N[k1]*N[k2]/(N[k1]+N[k2]))*tmp1)
    }
  }
  test_stat_median <- max(dif_matrix)

  ##standardized median
  median_sd_est <- vector("list", K)
  for (k in 1:K) {
    Xk_central <- dat[[k]]-rep(1,N[k])%o%median_list[[k]]
    norm_Xk <- sqrt(diag(Xk_central%*%t(Xk_central)))
    c_Xk <- mean(1/norm_Xk)
    B_Xk <- (t(Xk_central)%*%diag(1/norm_Xk))%*%t(t(Xk_central)%*%diag(1/norm_Xk))/N[k]
    median_sd_est[[k]] <- B_Xk/c_Xk^2
  }

  dif_matrix_std <- matrix(0, K, K)
  for (k1 in 1:(K-1)) {
    for (k2 in (k1+1):K) {
      Bxy <- (N[k2]*median_sd_est[[k1]]+N[k1]*median_sd_est[[k2]])/(N[k1]+N[k2])
      bxy <- sqrt(diag(Bxy))
      tmp2 <- abs(median_list[[k1]]-median_list[[k2]])/bxy
      dif_matrix_std[k1, k2] <- max(sqrt(N[k1]*N[k2]/(N[k1]+N[k2]))*tmp2)
    }
  }
  test_stat_median_std <- max(dif_matrix_std)

  #### bootstrap
  res_median_boot <- rep(0, n_boot)
  res_median_std_boot <- rep(0, n_boot)
  res_median_std_boot_old <- rep(0, n_boot)

  for(b in 1:n_boot){
    dat_boot <- vector("list", K)
    median_boot_list <- vector("list", K)
    for (k in 1:K) {
      Z_Xk <- rsign(N[k])%o%rep(1,p)
      dat_boot[[k]] <- (dat[[k]]-rep(1,N[k])%o%median_list[[k]])*Z_Xk
      median_boot_list[[k]] <- drop(Weiszfeld(dat_boot[[k]])$median)
    }

    dif_matrix_boot <- matrix(0, K, K)
    for (k1 in 1:(K-1)) {
      for (k2 in (k1+1):K) {
        tmp3 <- abs(median_boot_list[[k1]]-median_boot_list[[k2]])
        dif_matrix_boot[k1, k2] <- max(sqrt(N[k1]*N[k2]/(N[k1]+N[k2]))*tmp3)
      }
    }
    res_median_boot[b] <- max(dif_matrix_boot)

    median_sd_est_boot <- vector("list", K)
    for (k in 1:K) {
      Yk_central <- dat_boot[[k]]-rep(1,N[k])%o%median_boot_list[[k]]
      norm_Yk <- sqrt(diag(Yk_central%*%t(Yk_central)))
      c_Yk <- mean(1/norm_Yk)
      B_Yk <- (t(Yk_central)%*%diag(1/norm_Yk))%*%t(t(Yk_central)%*%diag(1/norm_Yk))/N[k]
      median_sd_est_boot[[k]] <- B_Yk/c_Yk^2
    }

    dif_matrix_std_boot <- matrix(0, K, K)
    for (k1 in 1:(K-1)) {
      for (k2 in (k1+1):K) {
        Bxy_boot <- (N[k2]*median_sd_est_boot[[k1]]+N[k1]*median_sd_est_boot[[k2]])/(N[k1]+N[k2])
        bxy_boot <- sqrt(diag(Bxy_boot))
        tmp4 <- abs(median_boot_list[[k1]]-median_boot_list[[k2]])/bxy_boot
        dif_matrix_std_boot[k1, k2] <- max(sqrt(N[k1]*N[k2]/(N[k1]+N[k2]))*tmp4)
      }
    }
    res_median_std_boot[b] <- max(dif_matrix_std_boot)

    dif_matrix_std_boot_old <- matrix(0, K, K)
    for (k1 in 1:(K-1)) {
      for (k2 in (k1+1):K) {
        Bxy <- (N[k2]*median_sd_est[[k1]]+N[k1]*median_sd_est[[k2]])/(N[k1]+N[k2])
        bxy <- sqrt(diag(Bxy))
        tmp5 <- abs(median_boot_list[[k1]]-median_boot_list[[k2]])/bxy
        dif_matrix_std_boot_old[k1, k2] <- max(sqrt(N[k1]*N[k2]/(N[k1]+N[k2]))*tmp5)
      }
    }
    res_median_std_boot_old[b] <- max(dif_matrix_std_boot_old)
  }

  test_p_value_non_std <- mean(test_stat_median < res_median_boot)
  test_p_value_std_ver1 <- mean(test_stat_median_std < res_median_std_boot_old)
  test_p_value_std_ver2 <- mean(test_stat_median_std < res_median_std_boot)

  return(list("test_p_value_non_std"=test_p_value_non_std,
              "test_p_value_std_ver1"=test_p_value_std_ver1,
              "test_p_value_std_ver2"=test_p_value_std_ver2,
              "test_stat_median"=test_stat_median,
              "test_stat_median_std"=test_stat_median_std,
              "res_median_boot"=res_median_boot,
              "res_median_boot_std_ver1"=res_median_std_boot_old,
              "res_median_boot_std_ver2"=res_median_std_boot))
}


#' Lin, Lopes and Muller (2021)'s MANOVA test for high-dimensional means
#' based on sample means.
#'
#' @description Let \eqn{\mu_1},..., \eqn{\mu_K} be the population means of \eqn{K}
#' groups. The hypothesis testing problem is
#' \deqn{H_0: \mu_1=\cdots=\mu_K ~~\text{versus}~~ H_1: H_0~\text{is not true}.}
#' The p-value of the test is approximated by bootstrapping centralized normal
#' random vectors with estimated covariance matrices.
#' The results include both approaches with and without standardization.
#'
#' @param dat a list of data matrices, with each element from each group
#' @param K the number of groups
#' @param N a vector contains the number of observation in each group
#' @param p dimensions of the data
#' @param n_boot the number of bootstrap iterations
#' @details The results include both approaches with and without standardization.
#' The approach with standardization refers to the case of \eqn{\tau=0} in
#' Lin, Lopes and Muller (2021), while the approach without standardization
#' refers to the case of \eqn{\tau=1} in the paper.
#'
#' @return A list containing the following objects:
#' \itemize{
#'   \item test_p_value_non_std - p-value of the test without standardization
#'   \item test_p_value_std - p-value of the test with standardization
#'   \item test_stat_mean_non_std - value of the test statistic without
#'   standardization
#'   \item test_stat_mean_std - value of the test statistic with standardization
#'   \item res_mean_boot_non_std - a vector of length \code{n_boot} containing
#'   values of the bootstrap version of the test statistic without standardization
#'   \item res_mean_std_boot - a vector of length \code{n_boot} containing
#'   values of the bootstrap version of the test statistic with standardization
#' }
#'
#' @examples
#' X1 <- matrix(rnorm(5000, 0, 1), 50, 100)
#' X2 <- matrix(rnorm(5000, 0.2, 1), 50, 100)
#' X3 <- matrix(rnorm(5000, 0.4, 1), 50, 100)
#' dat <- list(X1, X2, X3)
#' N <- c(50, 50, 50)
#' MANOVA_Mean_Lin2021(dat, K=3, N, p=100, n_boot=400)
#'
MANOVA_Mean_Lin2021 <- function (dat, K, N, p, n_boot=400) {
  mean_list <- vector("list", K)
  for (k in 1:K) {
    mean_list[[k]] <- apply(dat[[k]], 2, mean)
  }

  mean_dif_matrix <- matrix(0, K, K)
  for (k1 in 1:(K-1)) {
    for (k2 in (k1+1):K) {
      tmp1 <- abs(mean_list[[k1]]-mean_list[[k2]])
      mean_dif_matrix[k1, k2] <- max(sqrt(N[k1]*N[k2]/(N[k1]+N[k2]))*tmp1)
    }
  }
  test_stat_mean <- max(mean_dif_matrix)

  ##standardized mean
  mean_sd_est <- vector("list", K)
  for (k in 1:K) {
    mean_sd_est[[k]] <- cov(dat[[k]])*(N[k]-1)/N[k]
  }

  mean_dif_matrix_std <- matrix(0, K, K)
  for (k1 in 1:(K-1)) {
    for (k2 in (k1+1):K) {
      Sxy <- (N[k2]*mean_sd_est[[k1]]+N[k1]*mean_sd_est[[k2]])/(N[k1]+N[k2])
      sxy <- sqrt(diag(Sxy))
      tmp2 <- abs(mean_list[[k1]]-mean_list[[k2]])/sxy
      mean_dif_matrix_std[k1, k2] <- max(sqrt(N[k1]*N[k2]/(N[k1]+N[k2]))*tmp2)
    }
  }
  test_stat_mean_std <- max(mean_dif_matrix_std)

  #### bootstrap
  res_mean_boot <- rep(0, n_boot)
  res_mean_std_boot <- rep(0, n_boot)

  for(b in 1:n_boot){
    dat_boot <- vector("list", K)
    mean_boot_list <- vector("list", K)
    for (k in 1:K) {
      dat_boot[[k]] <- rmvnorm(N[k], rep(0, p), mean_sd_est[[k]])
      mean_boot_list[[k]] <- apply(dat_boot[[k]], 2, mean)
    }

    mean_dif_matrix_boot <- matrix(0, K, K)
    for (k1 in 1:(K-1)) {
      for (k2 in (k1+1):K) {
        tmp3 <- abs(mean_boot_list[[k1]]-mean_boot_list[[k2]])
        mean_dif_matrix_boot[k1, k2] <- max(sqrt(N[k1]*N[k2]/(N[k1]+N[k2]))*tmp3)
      }
    }
    res_mean_boot[b] <- max(mean_dif_matrix_boot)

    mean_dif_matrix_std_boot <- matrix(0, K, K)
    for (k1 in 1:(K-1)) {
      for (k2 in (k1+1):K) {
        Sxy <- (N[k2]*mean_sd_est[[k1]]+N[k1]*mean_sd_est[[k2]])/(N[k1]+N[k2])
        sxy <- sqrt(diag(Sxy))
        tmp5 <- abs(mean_boot_list[[k1]]-mean_boot_list[[k2]])/sxy
        mean_dif_matrix_std_boot[k1, k2] <- max(sqrt(N[k1]*N[k2]/(N[k1]+N[k2]))*tmp5)
      }
    }
    res_mean_std_boot[b] <- max(mean_dif_matrix_std_boot)
  }

  test_p_value_non_std <- mean(test_stat_mean<res_mean_boot)
  test_p_value_std <- mean(test_stat_mean_std<res_mean_std_boot)

  return(list("test_p_value_non_std"=test_p_value_non_std,
              "test_p_value_std"=test_p_value_std,
              "test_stat_mean_non_std"=test_stat_mean,
              "test_stat_mean_std"=test_stat_mean_std,
              "res_mean_boot_non_std"=res_mean_boot,
              "res_mean_std_boot"=res_mean_std_boot))
}

#' Cai and Xia (2014)'s MANOVA test for high-dimensional means with identity
#' transformed observations
#'
#' @description Let \eqn{\mu_1},..., \eqn{\mu_K} be the population means of \eqn{K}
#' groups. The hypothesis testing problem is
#' \deqn{H_0: \mu_1=\cdots=\mu_K ~~\text{versus}~~ H_1: H_0~\text{is not true}.}
#'
#' @param dat a list of data matrices, with each element from each group
#' @param K the number of groups
#' @param N a vector contains the number of observation in each group
#' @param p dimensions of the data
#' @param alpha significance level of the test
#' @details This function implements the MANOVA test in Cai and Xia (2014) with
#' identity transformed observations
#'
#' @return A list containing the following objects:
#' \itemize{
#'   \item alpha - the pre-specified significance level
#'   \item test_stat_Ip - value of the test statistic
#'   \item crit_val - value of the critical value
#'   \item test_res - test result, 1 (reject) or 0 (not reject)
#' }
#'
#' @examples
#' X1 <- matrix(rnorm(5000, 0, 1), 50, 100)
#' X2 <- matrix(rnorm(5000, 0.2, 1), 50, 100)
#' X3 <- matrix(rnorm(5000, 0.4, 1), 50, 100)
#' dat <- list(X1, X2, X3)
#' N <- c(50, 50, 50)
#' MANOVA_CaiXia_Ip(dat, K=3, N, p=100, alpha=0.05)
#'
MANOVA_CaiXia_Ip <- function (dat, K, N, p, alpha=0.05) {
  Cov_Ip = matrix(0, p, p)
  for (j in 1:K){
    Cov_Ip = Cov_Ip + cov(dat[[j]])*(N[j]-1)
  }
  Cov_Ip = Cov_Ip/(sum(N)-K)

  mean_list <- vector("list", K)
  for (k in 1:K) {
    mean_list[[k]] <- apply(dat[[k]], 2, mean)
  }

  est_Ip = 0
  for (l in 1:(K-1)){
    for (t in (l+1):K){
      est_Ip = est_Ip + (N[l]*N[t]/(N[l]+N[t]))*(mean_list[[l]]-mean_list[[t]])^2/diag(Cov_Ip)
    }
  }
  test_stat_Ip <- max(est_Ip)

  crinew <- -K*log(-gamma((K-1)/2)*log(1-alpha))
  crinew <- K*log(p)+K*(K-3)/2*log(log(p))+crinew

  return(list("test_stat_Ip"=test_stat_Ip,
              "crit_val"=crinew,
              "test_res"=(test_stat_Ip>crinew)*1))
}
